import java.sql.*;

class OracleCon {
	public static void main(String args[]) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("connecting");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@dbsvr1.cse.ust.hk:1521/comp3311.cse.ust.hk", "comp3311stu999", "password"); // specify which oracle service you are trying to connect and provide your login credentials 
			
			System.out.println("Connected");
			Statement stmt = con.createStatement();  //the handle for a new SQL query

			ResultSet rs = stmt.executeQuery("select * from students"); //exceute the query "select * from students" and store the result in rs 
			while (rs.next())
				System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
			//how to fetch data from the result 
			con.close();  //close the connection

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}