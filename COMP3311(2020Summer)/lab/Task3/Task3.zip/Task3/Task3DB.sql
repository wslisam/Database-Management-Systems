/* COMP 3311: Conference Submission Review Management System - Task3DB.sql */

clear screen
set feedback off
set heading off
select '*** Creating the database ***' from dual;
set heading on
set termout off

drop table Discussion;
drop table Review;
drop table Assigned;
drop table Prefers;
drop table PCChair;
drop table AuthorOf;
drop table Submission;
drop table PCMember;
drop table Person;

/* Create the database */

create table Person (
	personId    smallint  primary key,
    username    char(10) default null unique check (regexp_like(rtrim(username), '^[a-z]{3,10}$')),
	title       char(5) default null check (title in ('Mr', 'Ms', 'Miss', 'Dr', 'Prof', null)),
	name        varchar2(50) not null,
	institution varchar2(100) not null,
	country     varchar2(30) not null,
    email       varchar2(50) not null unique);

create table PCMember (
	personId    smallint primary key references Person(personId) on delete cascade);
    
create table Submission (
	submissionNo    smallint primary key,
	title           varchar2(100) not null,
    abstract        varchar2(300) not null,
	submissionType  varchar2(20) default 'research' not null check (submissionType in ('demo', 'industrial', 'research', 'vision')),
	status          varchar2(9) default null check (status in ('accept', 'reject', 'withdrawn', null)),
    contactAuthor   smallint references Person(personId) on delete cascade);

create table Assigned (
	submissionNo    smallint references Submission(submissionNo) on delete cascade,
	personId        smallint references PCMember(personId) on delete cascade,
	primary key(submissionNo,personId));

create table Review (
	submissionNo            smallint references Submission(submissionNo) on delete cascade,
	personId                smallint references PCMember(personId) on delete cascade,
	relevant                char(1) not null check(relevant in ('Y', 'N', 'M')),
	technicallyCorrect      char(1) not null check(technicallyCorrect in ('Y', 'N', 'M')),
	lengthAndContent        char(1) not null check(lengthAndContent in ('Y', 'N', 'M')),
	confidence              number(2,1) not null check(confidence between 0.5 and 1),
    originality             smallint not null check(originality in (1, 2, 3, 4, 5)),
	impact                  smallint not null check(impact in (1, 2, 3, 4, 5)),
	presentation            smallint not null check(presentation in (1, 2, 3, 4, 5)),
	technicalDepth          smallint not null check(technicalDepth in (1, 2, 3, 4, 5)),
	overallRating           smallint not null check(overallRating in (1, 2, 3, 4, 5)),
	mainContribution        varchar2(300) not null,
	strongPoints            varchar2(300) not null,
	weakPoints              varchar2(300) not null,
	overallSummary          varchar2(300) not null,
	detailedComments        varchar2(1000),
	confidentialComments    varchar2(300),
	primary key(submissionNo,personId),
    foreign key (submissionNo, personId) references Assigned(submissionNo, personId));

create table Discussion (
	sequenceNo      smallint,
	submissionNo    smallint references Submission(submissionNo) on delete cascade,
	personId        smallint references PCMember(personId) on delete cascade,
	comments        varchar2(200) not null,
	primary key(sequenceNo,submissionNo,personId),
    foreign key (submissionNo, personId) references Review(submissionNo, personId));

create table AuthorOf (
	submissionNo    smallint references Submission(submissionNo) on delete cascade,
	personId        smallint references Person(personId) on delete cascade,
	primary key(submissionNo,personId));

create table PCChair(
	personId    smallint primary key references PCMember(personId) on delete cascade);

create table Prefers (
	submissionNo    smallint references Submission(submissionNo) on delete cascade,
	personId        smallint references PCMember(personId) on delete cascade,
	preference      smallint not null check (preference in (1, 2, 3, 4, 5)),
	primary key(submissionNo,personId));


/* Populate the database */

/********** Person table **********/
insert into Person values (1,'cafarella',null,'Michael J. Cafarella','University of Michigan','USA','michjc@umich.edu');
insert into Person values (2,'jag','Prof','H. V. Jag','University of Michigan','USA','jag@umich.edu');
insert into Person values (3,null,'Mr','Aditya Parameswaran','Stanford University','USA','adityagp@cs.stanford.edu');
insert into Person values (4,null,'Dr','Nilesh Dalvi','Yahoo! Research','USA','ndalvi@yahooinc.com');
insert into Person values (5,'molina','Prof','Hector Molina','Stanford University','USA','hector@cs.stanford.edu');
insert into Person values (6,null,'Dr','Rajeev Rastogi','Yahoo! Research','USA','rrastogi@yahooinc.com');
insert into Person values (7,'crestan','Dr','Eric Crestan','Yahoo! Labs','USA','ecrestan@yahoo-inc.com');
insert into Person values (8,'pantel','Dr','Patrick Pantel','Yahoo! Labs','USA','ppantel@yahoo-inc.com');
insert into Person values (9,'zadoro','Prof','Vladimir Zadoro','University of Pittsburgh','USA','vladimir@sis.pitt.edu');
insert into Person values (10,null,'Mr','Ying-Feng Hsu','University of Pittsburgh','USA','yfhsu@sis.pitt.edu');
insert into Person values (11,null,'Prof','Tim Weninger','University of Notre Dame','USA','tweninge@nd.edu');
insert into Person values (12,null,'Prof','William H. Hsu','Kansas State University','USA','bhsu@cis.ksu.edu');
insert into Person values (13,'han','Prof','Jiawei Han','University of Illinois at Urbana-Champaign','USA','hanj@cs.uiuc.edu');
insert into Person values (14,'krishna','Mr','Rajasekar Krishna','IBM Research - Almaden','USA','rajase@us.ibm.com');
insert into Person values (15,null,'Mr','Jeffrey Naughton','University of Wisconsin','USA','naughton@cs.wisc.edu');
insert into Person values (16,'lock','Prof','Frank Lock','Hong Kong University of Science and Technology','China','lock@cse.ust.hk');
insert into Person values (17,'fan','Mr','Ju Fan','National University of Singapore','Singapore','jfan@comp.nus.edu.sg');
insert into Person values (18,'ooi','Prof','Beng Chin Ooi','National University of Singapore','Singapore','ooibc@comp.nus.edu.sg');
insert into Person values (19,'swart','Mr','Garret Swart','Oracle Corporation','USA','garret.swart@oracle.com');
insert into Person values (20,null,'Mr','Nelson Ray','Metamarkets Group, Inc.','USA','ncray86@gmail.com');
insert into Person values (21,'soliman','Dr','Mohamed A. Soliman','Pivotal Inc.','USA','Soliman@pivotal.io');
insert into Person values (22,'chen','Prof','Lei Chen','Hong Kong University of Science and Technology','China','leichen@cse.ust.hk');
insert into Person values (23,'rundens','Prof','Elke Rundens','Worcester Polytechnic Institute','USA','rundens@cs.wpi.edu');
insert into Person values (24,'yuj','Prof','Jeffrey Yu','Chinese University of Hong Kong','China','yu@se.cuhk.edu.hk');
insert into Person values (25,'larson','Dr','Paul Larson','Microsoft Research','USA','palarson@microsoft.com');
insert into Person values (26,null,null,'Anil Shan','MIT CSAI','USA','anil@csail.mit.edu');
insert into Person values (27,null,'Dr','Alekh Jinda','Microsoft Research','USA','aljindal@microsoft.com');
insert into Person values (28,null,null,'Yi Lu','MIT CSAI','USA','yilu@csail.mit.edu');
insert into Person values (29,'madden','Prof','Samuel Madden','MIT CSAI','USA','madden@csail.mit.edu');
insert into Person values (30,'varma','Dr','Paroma Varma','Stanford University','USA','paroma@stanford.edu');
insert into Person values (31,'rec','Prof','Christopher Re','Stanford University','USA','chrismre@cs.stanford.edu');

/********** PCMember table **********/
insert into PCMember values (2);
insert into PCMember values (7);
insert into PCMember values (8);
insert into PCMember values (13);
insert into PCMember values (16); 
insert into PCMember values (18);
insert into PCMember values (22);
insert into PCMember values (23);
insert into PCMember values (24);
insert into PCMember values (25);

/********** PCChair table **********/
insert into PCChair values (16);

/********** Submission table **********/

insert into Submission values (1,'Example-Driven Schema Mapping','End-users increasingly find the need to perform light-weight, customized data integration. State-of-the-art tools usually require an in-depth understanding of the semantics of multiple schemas. We propose a system, MWeaver, that facilitates data integration for end-users.','research','reject',1);
insert into Submission values (2,'Optimal Schemes for Robust Web Extraction','We consider the problem of constructing robust wrappers for web information extraction. We consider two models to study robustness formally: the adversarial model and probabilistic model. We demonstrate that our algorithms can reduce wrapper breakage by up to 500% over existing techniques.','research','accept',5);
insert into Submission values (3,'Web-Scale Knowledge Extraction','We propose a classification algorithm and a rich feature set for automatically recognizing layout tables and attribute/value tables. In 79% of our Web tables, our method finds the correct protagonist in its top three returned candidates.','research',null,7);
insert into Submission values (4,'Efficient Fusion of Historical Data','Historical data may include severe data conflicts that prevent researchers from obtaining the correct answers to queries on an integrated historical database. We consider an efficient approach to large-scale historical data fusion.','research',null,9);
insert into Submission values (5,'CETR - Content Extraction via Tag Ratios','Content Extraction via Tag Ratios (CETR) is a method to extract content text from diverse webpages using the HTML document''s tag ratios. We evaluate our approach against a large set of alternative methods, which shows that CETR achieves better content extraction performance than existing methods.','research',null,13);
insert into Submission values (6,'Towards User-Friendly Entity Resolution','We explore the possibility of treating user input as an integral part of the entity resolution process. We design a simple two-stage approach that separates merging and splitting records into two separate stages.','research',null,14);
insert into Submission values (7,'TsingNUS: A Location-based Service System','TsingNUS aims to provide users with more user-friendly location-aware search experiences. TsingNUS incorporates continuous search to efficiently support continuously moving queries in a client-server system thereby reducing the communication cost between the client and server.','demo',null,17);
insert into Submission values (8,'A Java Stream Computational Model for Big Data','The addition of lambda expressions and a Stream API in Java 8 provide a powerful and expressive query language. We build on Java 8 Stream and add a DistributableStream abstraction that supports federated query execution over an extensible set of distributed compute engines.','industrial',null,19);
insert into Submission values (9,'Druid: A Real-time Analytical Data Store','Druid is an open source data store designed for real-time exploratory analytics on large data sets. It combines column-oriented storage layout, distributed, shared-nothing architecture, and advanced indexing to allow for the arbitrary exploration of billion-row tables with sub-second latencies.','industrial',null,21);
insert into Submission values (10,'Orca: A Modular Query Optimizer','Orca, a new query optimizer for all Pivotal data management products, is a comprehensive development uniting state-of-the-art query optimization technology with original research resulting in a modular and portable optimizer architecture.','industrial',null,21);
insert into Submission values (11,'Amoeba: A Shape Changing, Big Data Storage System','Amoeba is a distributed storage system which uses adaptive multi-attribute data partitioning to efficiently support ad-hoc as well as recurring queries.','demo',null,29);
insert into Submission values (12,'Snuba: Automating Weak Supervision to Label Training Data','Snuba automatically generates heuristics using a small labeled dataset to assign training labels to a large, unlabeled dataset in the weak supervision setting. Snuba iteratively repeats this process until the heuristics together label a large portion of the unlabeled data.','research',null,30);
insert into Submission values (13,'Training with Natural Language','Babble Labble is a framework for generating labels for large training sets from natural language explanations. By learning from natural language explanations of labeling decisions, we achieve comparable quality to fully supervised approaches with a fraction of the data.','industrial',null,31);
insert into Submission values (14,'SystemML: Declarative Machine Learning on MapReduce','In this paper, we propose SystemML in which ML algorithms are expressed in a higher-level language and are compiled and executed in a MapReduce environment.','research','withdrawn',14);

/**** AuthorOf table **********/

insert into AuthorOf values (1,1);
insert into AuthorOf values (1,2);
insert into AuthorOf values (2,3);
insert into AuthorOf values (2,4);
insert into AuthorOf values (2,5);
insert into AuthorOf values (2,6);
insert into AuthorOf values (3,7);
insert into AuthorOf values (3,8);
insert into AuthorOf values (4,9);
insert into AuthorOf values (4,10);
insert into AuthorOf values (5,11);
insert into AuthorOf values (5,12);
insert into AuthorOf values (5,13);
insert into AuthorOf values (6,14);
insert into AuthorOf values (6,15);
insert into AuthorOf values (7,17);
insert into AuthorOf values (8,19);
insert into AuthorOf values (9,20);
insert into AuthorOf values (9,21);
insert into AuthorOf values (10,21);
insert into AuthorOf values (11,26);
insert into AuthorOf values (11,27);
insert into AuthorOf values (11,28);
insert into AuthorOf values (11,29);
insert into AuthorOf values (12,30);
insert into AuthorOf values (12,31);
insert into AuthorOf values (13,31);
insert into AuthorOf values (14,14);

/********** Prefers table **********/
insert into Prefers values (1,2,2);
insert into Prefers values (3,2,3);
insert into Prefers values (5,2,4);
insert into Prefers values (1,7,3);
insert into Prefers values (2,7,4);
insert into Prefers values (4,8,1);
insert into Prefers values (5,8,4);
insert into Prefers values (6,8,4);
insert into Prefers values (7,13,3);
insert into Prefers values (8,13,3);
insert into Prefers values (5,18,1);
insert into Prefers values (9,18,2);
insert into Prefers values (1,22,1);
insert into Prefers values (2,22,2);
insert into Prefers values (3,22,1);
insert into Prefers values (4,22,2);
insert into Prefers values (6,22,3);
insert into Prefers values (7,23,4);
insert into Prefers values (8,23,3);
insert into Prefers values (3,24,4);
insert into Prefers values (4,24,5);
insert into Prefers values (8,24,2);
insert into Prefers values (9,24,1);
insert into Prefers values (7,25,4);
insert into Prefers values (9,25,4);

/********** Assigned table **********/
insert into Assigned values (3,2);
insert into Assigned values (5,2);
insert into Assigned values (10,2);
insert into Assigned values (1,7);
insert into Assigned values (2,7);
insert into Assigned values (4,7);
insert into Assigned values (5,8);
insert into Assigned values (6,8);
insert into Assigned values (10,8);
insert into Assigned values (1,13);
insert into Assigned values (7,13);
insert into Assigned values (8,13);
insert into Assigned values (2,16);
insert into Assigned values (6,16);
insert into Assigned values (9,16);
insert into Assigned values (4,22);
insert into Assigned values (6,22);
insert into Assigned values (8,22);
insert into Assigned values (1,23);
insert into Assigned values (7,23);
insert into Assigned values (8,23);
insert into Assigned values (2,24);
insert into Assigned values (3,24);
insert into Assigned values (4,24);
insert into Assigned values (7,25);
insert into Assigned values (9,25);
insert into Assigned values (10,25);

/********** Review table **********/
insert into Review values (1,7,'Y','Y','Y',1.0,5,4,5,4,5,'The paper proposes a new way to do schema mappings that involve the user providing example instances of the result data. The system then constructs the schema mapping "behind the scenes" from the provided examples.','The described example-based schema mapping is novel in that it has not been used before specifically for the schema mapping problem.','The user study is fairly small-scale. It is not clear that any statistical significance can be drawn from such a small-scale study, though the results do look promising for the given example.','An excellent paper.',null,null);
insert into Review values (1,13,'Y','Y','Y',0.9,4,3,3,4,4,'The paper proposes a new way to do schema mappings.','The technique is novel and technique is efficient. ','Applicable only to small-scale schema mappings.','An interesting technique to do schema mappings.',null,null);
insert into Review values (1,23,'Y','N','Y',1.0,3,1,4,4,2,'The paper proposes a new way to do schema mappings, but the algorithm is incorrect.','None really.','The algorithm is incorrect.','Should be rejected as it is technically not correct.',null,null);
insert into Review values (2,7,'Y','Y','Y',0.8,2,1,1,2,2,'This paper focuses on robust wrapper construction. In particular, two models are studied: the adversarial model and the probabilistic model.','A new approach, which has been proved to be the optimal for wrapper robustness, is proposed.','The paper is presented in a way which is very difficult to understand. I would like to see some examples to help explain the models.','This paper requires further work to make it acceptable for inclusion in the conference.',null,null);
insert into Review values (2,16,'Y','Y','Y',0.8,3,3,3,3,3,'A robust wrapper is proposed that is shown to be robust. The paper is clearly presented and well motivated.','An adversarial and a probabilistic model are proposed.','The two models care well motivated.','A good paper on a timely topic.',null,null);
insert into Review values (2,24,'Y','Y','Y',0.8,2,2,3,3,3,'A provable most robust wrapper is proposed for the two models. Experiments show the robustness of the wrapper. The paper is presented clearly and each part is well motivated.','Two models, adversarial model and probabilistic model, are proposed. For each model, an extraction confidence is provided.','The two models could be better motivated.','A well written paper on an interesting and timely topic that is very relevant to the conference.',null,null);
insert into Review values (4,7,'Y','Y','Y',0.9,4,3,3,4,4,'When integrating data from several documents, several types of conflicts may arise in the data. These conflicts may result in inaccurate query results due to over- or under-estimation. This paper discusses three types of conflicts.','The paper clearly defines each of the three types of conflicts with examples and how they may affect the results of queries.','No convincing validation of the method on real historical data is provided.','The paper is suitable for the conference.',null,null);
insert into Review values (4,22,'Y','Y','Y',1.0,4,3,4,3,4,'This paper discusses three types of conflicts that may arise when integrating data from several documents.','A method for dealing with this problem for temporal conflicts is proposed.','There are some technical errors in the paper (see the detailed comments).','The paper is OK for the conference.','In Section 4.1 the equation for RO(t1,t2) seems to be wrong. Since you are taking the absolute value of the sum and overlap, when there is a (non-zero) time gap between two time intervals, the value for RO will still be greater than 0.',null);
insert into Review values (4,24,'Y','Y','Y',0.8,3,4,4,3,4,'This paper discusses three types of conflicts: temporal conflicts, due to overlapping time intervals, spatial conflicts, due to overlapping locations and name conflicts, due to the use of different names that refer to the same concept.','Dealing with conflicts in historical data is an important and interesting problem.','The assumptions in Section 4.2.1 on which the conflict resolution method and experiments are based are not adequately justified.','The paper is acceptable for the conference.',null,null);
insert into Review values (6,8,'N','Y','Y',1.0,1,2,2,2,2,'This paper focuses on user feedback during the entity resolution (ER) process. It identifies a set of properties for making the ER methods transparent such that users can easily evaluate the results during the resolution process.','Considering user feedback to improve ER result seems very useful.','Although the paper describes what the user would do to improve the final result, it does not mention how the user does it. Does the user check all the intermediate results or choose part of the results? Is there any way to check whether new rules are applicable or not?','This approach does not seem to be practical in practice.',null,null);
insert into Review values (6,22,'N','Y','Y',0.9,3,3,2,2,3,'The paper proposes a two-stage ER approach in which users can incrementally check, debug or improve the intermediate results. During the stages, this approach can improve precision and recall separately.','The idea of improving precision and recall separately is interesting.','The experiments only involve two datasets. A lack of experiments on more datasets and other domains, make the work less convincing.','While the ideas proposed in this paper are interesting, more experiments are needed to verify the practicality of this proposed ER method.',null,null);

/********** Discussion table **********/
insert into Discussion values (1,1,7,'On a more careful reading I agree with Eric1''s assessment that the algorithm is incorrect. I also have some problems with the paper''s ''liberal'' use of other people''s text.');
insert into Discussion values (2,1,13,'Yes, I agree that the paper is technically incorrect and is possibly repetitive of other papers. For my part, I am willing to lower my overall score to 3.');
insert into Discussion values (3,1,7,'I have also decided to reduce my overall score for this paper to 3.');
insert into Discussion values (4,1,23,'It seems that with the revised overall score this paper will not be accepted.');
insert into Discussion values (5,1,7,'OK I am happy with this result. I guess we are done discussing this paper.');
insert into Discussion values (1,2,24,'I feel that with some minor rewriting, the paper would be acceptable for inclusion in the conference. I would really like to see this paper accepted.');
insert into Discussion values (2,2,7,'Yes, adding some examples would make the paper much clearer and easier to understand. I am willing to change my overall score to 7 if you are willing to oversee the revision of the paper.');
insert into Discussion values (3,2,24,'OK I am willing to oversee the revision of the paper.');

/* Write the data to the database */
set feedback on
commit;