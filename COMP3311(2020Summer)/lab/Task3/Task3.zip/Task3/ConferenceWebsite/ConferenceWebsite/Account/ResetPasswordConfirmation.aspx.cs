﻿using System.Web.UI;

namespace ConferenceWebsite.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}