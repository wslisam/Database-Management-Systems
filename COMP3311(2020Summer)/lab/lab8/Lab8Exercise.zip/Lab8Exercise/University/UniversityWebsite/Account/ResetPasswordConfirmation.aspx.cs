﻿using System.Web.UI;

namespace UniversityWebsite.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}