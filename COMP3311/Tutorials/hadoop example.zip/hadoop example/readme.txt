Hadoop is in 
	/opt/hadoop-3.1.2


set environment 
	export JAVA_HOME=/usr/java/default
	export PATH=${JAVA_HOME}/bin:${PATH}
	export HADOOP_CLASSPATH=${JAVA_HOME}/lib/tools.jar
	
Compile
	bin/hadoop com.sun.tools.javac.Main WordCount.java
	jar cf wc.jar WordCount*.class
	
Sample files:
	file01
	file02

Deploy Files to HDFS:
	bin/hdfs dfs -ls /user/ji/
	bin/hdfs dfs -mkdir /user/ji/wordcount/input
	
copy local file to hdfs:
	bin/hdfs dfs -put ./file01 /user/ji/wordcount/input/
	bin/hdfs dfs -put ./file02 /user/ji/wordcount/input/
	
check the files on hdfs:
	 bin/hdfs dfs -ls /user/ji/wordcount/input/
	 bin/hdfs dfs -cat /user/ji/wordcount/input/file01
	 
	 
Run the compiled jar file:
	bin/hadoop jar wc.jar WordCount /user/ji/wordcount/input /user/ji/wordcount/output
	make sure /output is not yet created in /user/ji/wordcount/output  
	
Check the result:
	bin/hadoop fs -ls /user/ji/wordcount/output/
	bin/hadoop fs -cat /user/ji/wordcount/output/part-r-00000
	
For More details: 
	https://hadoop.apache.org/docs/r3.1.2/hadoop-project-dist/hadoop-common/SingleCluster.html#Standalone_Operation
	https://hadoop.apache.org/docs/r3.1.2/hadoop-mapreduce-client/hadoop-mapreduce-client-core/MapReduceTutorial.html#Purpose